package com.alurachallenges.forohub.forumengineapi.Domain.user.DTO;

public record DTOUserReply(
        Long id,
        String name) {}