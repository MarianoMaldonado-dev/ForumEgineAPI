package com.alurachallenges.forohub.forumengineapi.Domain.Topics.Validations;

public class DuplicateRegisters {
}
