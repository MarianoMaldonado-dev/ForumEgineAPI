package com.alurachallenges.forohub.forumengineapi.Domain.user;

public class UserRegister {
}
