package com.alurachallenges.forohub.forumengineapi.Infrastructure.Security;

public record DTOJWTToken(String token) {
}
