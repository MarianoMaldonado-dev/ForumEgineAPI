package com.alurachallenges.forohub.forumengineapi.Domain.Topics.Validations;

public enum Status {
    ACTIVO,
    INACTIVO
}
